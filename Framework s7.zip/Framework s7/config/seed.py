import os
from sqlmodel import Session, select
from config.db import engine
from models.rol import Rol
from models.usuario import Usuario
from lib.pwd import get_password_hash


def seed_roles():
    with Session(engine) as session:
        roles = session.exec(select(Rol)).all()
        nombres = {rol.nombre.lower() for rol in roles}
        if "admin" not in nombres:
            session.add(Rol(nombre="Admin", descripcion="Administrador del sistema"))
        if "vendedor" not in nombres:
            session.add(Rol(nombre="Vendedor", descripcion="Usuario encargado de realizar ventas"))
        session.commit()


def seed_admin():
    with Session(engine) as session:
        admin_role = session.exec(select(Rol).where(Rol.nombre.ilike("admin"))).first()
        if not admin_role:
            return
        username = os.getenv("ADMIN_USERNAME", "admin")
        password = os.getenv("ADMIN_PASSWORD", "admin123")
        admin = session.exec(select(Usuario).where(Usuario.username == username)).first()
        if not admin:
            admin = Usuario(
                username=username,
                password=get_password_hash(password),
                nombre="Administrador",
                apellido="Sistema",
                telefono="700000000",
                correo=None,
                id_rol=admin_role.id,
            )
            session.add(admin)
            session.commit()
