from fastapi import HTTPException, status
from sqlmodel import Session
from models.rol import Rol

ADMIN_ROLE_ID = 1
VENDEDOR_ROLE_ID = 2


def role_name(token: dict, session: Session) -> str:
    id_rol = token.get("id_rol")
    if id_rol is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Usuario sin rol asignado")
    rol = session.get(Rol, id_rol)
    if not rol:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Rol no válido")
    return rol.nombre.lower()


def require_admin(token: dict, session: Session):
    if role_name(token, session) != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Solo el administrador puede realizar esta acción")


def require_admin_or_vendor(token: dict, session: Session):
    if role_name(token, session) not in {"admin", "vendedor"}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Rol no autorizado")


def is_admin(token: dict, session: Session) -> bool:
    return role_name(token, session) == "admin"
