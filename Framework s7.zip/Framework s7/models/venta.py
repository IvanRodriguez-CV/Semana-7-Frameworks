from sqlmodel import SQLModel, Field
from datetime import datetime
from decimal import Decimal
from typing import Optional

class VentaBase(SQLModel):
    fecha: datetime = Field(nullable=False)
    total: Decimal = Field(nullable=False, ge=0)
    id_cliente: int = Field(nullable=False, foreign_key="clientes.id")
    id_usuario: int = Field(nullable=False, foreign_key="usuarios.id")
    id_tipo_pago: int = Field(nullable=False, foreign_key="tipo_pago.id")
    estado: str = Field(default="editable", nullable=False, max_length=20)

class Venta(VentaBase, table=True):
    __tablename__ = "ventas"
    id: int | None = Field(default=None, primary_key=True)
    created_at: datetime | None = Field(default_factory=datetime.utcnow)
    updated_at: datetime | None = Field(default_factory=datetime.utcnow)

class VentaCreate(SQLModel):
    fecha: datetime
    total: Decimal = Field(ge=0)
    id_cliente: int
    id_tipo_pago: int

class VentaUpdate(SQLModel):
    fecha: datetime
    total: Decimal = Field(ge=0)
    id_cliente: int
    id_tipo_pago: int
    estado: str = Field(default="editable", max_length=20)
