from datetime import datetime
from fastapi import APIRouter, HTTPException, status, Query
from models.categoria import Categoria, CategoriaCreate, CategoriaUpdate
from sqlmodel import select
from config.session_Dependencia import SessionDeDependencia
from config.segurity_Dependencia import Token_Dependencia
from config.permissions import require_admin, require_admin_or_vendor
from models.producto import Producto

router = APIRouter()


@router.get("/categorias", response_model=list[Categoria], status_code=status.HTTP_200_OK)
def get_categorias(session: SessionDeDependencia, token: Token_Dependencia, offset: int = Query(0, ge=0), limit: int = Query(20, ge=1)):
    require_admin_or_vendor(token, session)
    return session.exec(select(Categoria).offset(offset).limit(limit)).all()


@router.get("/categorias/{id}", response_model=Categoria, status_code=status.HTTP_200_OK)
def get_categoria(id: int, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    categoria = session.get(Categoria, id)
    if not categoria:
        raise HTTPException(status_code=404, detail="Categoria no encontrada")
    return categoria


@router.post("/categorias", response_model=Categoria, status_code=status.HTTP_201_CREATED)
def create_categoria(datos_categoria: CategoriaCreate, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin(token, session)
    categoria_nueva = Categoria.model_validate(datos_categoria)
    session.add(categoria_nueva)
    session.commit()
    session.refresh(categoria_nueva)
    return categoria_nueva


@router.delete("/categorias/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_categoria(id: int, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin(token, session)
    categoria = session.get(Categoria, id)
    if not categoria:
        raise HTTPException(status_code=404, detail="Categoria no encontrada")
    asociado = session.exec(select(Producto).where(
        Producto.id_categoria == id)).first()
    if asociado:
        raise HTTPException(
            status_code=409, detail="No se puede eliminar la categoría porque tiene productos asociados")
    session.delete(categoria)
    session.commit()
    return None


@router.put("/categorias/{id}", response_model=Categoria, status_code=status.HTTP_200_OK)
def update_categoria(id: int, datos_categoria: CategoriaUpdate, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin(token, session)
    categoria = session.get(Categoria, id)
    if not categoria:
        raise HTTPException(status_code=404, detail="Categoria no encontrada")
    categoria.nombre = datos_categoria.nombre
    categoria.descripcion = datos_categoria.descripcion
    categoria.updated_at = datetime.utcnow()
    session.add(categoria)
    session.commit()
    session.refresh(categoria)
    return categoria
