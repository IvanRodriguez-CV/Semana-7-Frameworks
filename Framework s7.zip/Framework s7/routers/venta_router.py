from datetime import datetime
from fastapi import APIRouter, HTTPException, status, Query
from sqlmodel import select
from config.session_Dependencia import SessionDeDependencia
from config.segurity_Dependencia import Token_Dependencia
from config.permissions import require_admin, require_admin_or_vendor, role_name
from models.venta import Venta, VentaCreate, VentaUpdate
from models.cliente import Cliente
from models.usuario import Usuario
from models.tipo_pago import TipoPago
from models.detalle_venta import DetalleVenta

router = APIRouter()


def validar_referencias(datos, session):
    if not session.get(Cliente, datos.id_cliente):
        raise HTTPException(status_code=404, detail=f"Cliente con id {datos.id_cliente} no encontrado")
    if not session.get(TipoPago, datos.id_tipo_pago):
        raise HTTPException(status_code=404, detail=f"Tipo de pago con id {datos.id_tipo_pago} no encontrado")


def validar_estado(venta: Venta):
    if venta.estado.lower() != "editable":
        raise HTTPException(status_code=409, detail="La venta ya no está editable")

@router.get("/ventas", response_model=list[Venta], status_code=status.HTTP_200_OK)
def get_ventas(session: SessionDeDependencia, token: Token_Dependencia, offset: int = Query(0, ge=0), limit: int = Query(100, ge=1)):
    require_admin_or_vendor(token, session)
    if role_name(token, session) == "admin":
        return session.exec(select(Venta).offset(offset).limit(limit)).all()
    return session.exec(select(Venta).where(Venta.id_usuario == token["id"]).offset(offset).limit(limit)).all()

@router.get("/ventas/{id}", response_model=Venta, status_code=status.HTTP_200_OK)
def get_venta(id: int, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    venta = session.get(Venta, id)
    if not venta: raise HTTPException(status_code=404, detail="Venta no encontrada")
    if role_name(token, session) != "admin" and venta.id_usuario != token["id"]:
        raise HTTPException(status_code=403, detail="El vendedor solo puede consultar sus propias ventas")
    return venta

@router.post("/ventas", response_model=Venta, status_code=status.HTTP_201_CREATED)
def create_venta(datos: VentaCreate, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    validar_referencias(datos, session)
    if not session.get(Usuario, token["id"]):
        raise HTTPException(status_code=401, detail="Usuario autenticado no encontrado")
    venta = Venta(fecha=datos.fecha, total=datos.total, id_cliente=datos.id_cliente,
                  id_usuario=token["id"], id_tipo_pago=datos.id_tipo_pago, estado="editable")
    session.add(venta); session.commit(); session.refresh(venta)
    return venta

@router.delete("/ventas/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_venta(id: int, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin(token, session)
    venta = session.get(Venta, id)
    if not venta: raise HTTPException(status_code=404, detail="Venta no encontrada")
    if session.exec(select(DetalleVenta).where(DetalleVenta.id_venta == id)).first():
        raise HTTPException(status_code=409, detail="No se puede eliminar la venta porque tiene detalles asociados")
    session.delete(venta); session.commit(); return None

@router.put("/ventas/{id}", response_model=Venta, status_code=status.HTTP_200_OK)
def update_venta(id: int, datos: VentaUpdate, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    venta = session.get(Venta, id)
    if not venta: raise HTTPException(status_code=404, detail="Venta no encontrada")
    admin = role_name(token, session) == "admin"
    if not admin and venta.id_usuario != token["id"]:
        raise HTTPException(status_code=403, detail="El vendedor solo puede actualizar sus propias ventas")
    if not admin: validar_estado(venta)
    validar_referencias(datos, session)
    if datos.estado.lower() not in {"editable", "finalizada", "anulada"}:
        raise HTTPException(status_code=400, detail="Estado no válido. Use editable, finalizada o anulada")
    venta.fecha = datos.fecha; venta.total = datos.total; venta.id_cliente = datos.id_cliente
    venta.id_tipo_pago = datos.id_tipo_pago; venta.estado = datos.estado.lower()
    venta.updated_at = datetime.utcnow()
    session.add(venta); session.commit(); session.refresh(venta)
    return venta
