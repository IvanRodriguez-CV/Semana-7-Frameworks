from datetime import datetime
from fastapi import APIRouter, HTTPException, status, Query
from sqlmodel import select
from config.session_Dependencia import SessionDeDependencia
from config.segurity_Dependencia import Token_Dependencia
from config.permissions import require_admin_or_vendor, require_admin
from models.cliente import Cliente, ClienteCreate, ClienteUpdate, ClienteUpdatePatch
from models.venta import Venta

router = APIRouter()

@router.get("/clientes", response_model=list[Cliente], status_code=status.HTTP_200_OK)
def get_clientes(session: SessionDeDependencia, token: Token_Dependencia, offset: int = Query(0, ge=0), limit: int = Query(100, ge=1)):
    require_admin_or_vendor(token, session)
    return session.exec(select(Cliente).offset(offset).limit(limit)).all()

@router.get("/clientes/{id}", response_model=Cliente, status_code=status.HTTP_200_OK)
def get_cliente(id: int, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    cliente = session.get(Cliente, id)
    if not cliente: raise HTTPException(status_code=404, detail="Cliente no encontrado")
    return cliente

@router.post("/clientes", response_model=Cliente, status_code=status.HTTP_201_CREATED)
def create_cliente(datos: ClienteCreate, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    cliente = Cliente.model_validate(datos); session.add(cliente); session.commit(); session.refresh(cliente)
    return cliente

@router.delete("/clientes/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_cliente(id: int, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin(token, session)
    cliente = session.get(Cliente, id)
    if not cliente: raise HTTPException(status_code=404, detail="Cliente no encontrado")
    if session.exec(select(Venta).where(Venta.id_cliente == id)).first():
        raise HTTPException(status_code=409, detail="No se puede eliminar el cliente porque tiene ventas asociadas")
    session.delete(cliente); session.commit(); return None

@router.put("/clientes/{id}", response_model=Cliente, status_code=status.HTTP_200_OK)
def update_cliente(id: int, datos: ClienteUpdate, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    cliente = session.get(Cliente, id)
    if not cliente: raise HTTPException(status_code=404, detail="Cliente no encontrado")
    cliente.sqlmodel_update(datos.model_dump()); cliente.updated_at = datetime.utcnow()
    session.add(cliente); session.commit(); session.refresh(cliente); return cliente

@router.patch("/clientes/{id}", response_model=Cliente, status_code=status.HTTP_200_OK)
def patch_cliente(id: int, datos: ClienteUpdatePatch, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    cliente = session.get(Cliente, id)
    if not cliente: raise HTTPException(status_code=404, detail="Cliente no encontrado")
    cliente.sqlmodel_update(datos.model_dump(exclude_unset=True)); cliente.updated_at = datetime.utcnow()
    session.add(cliente); session.commit(); session.refresh(cliente); return cliente
