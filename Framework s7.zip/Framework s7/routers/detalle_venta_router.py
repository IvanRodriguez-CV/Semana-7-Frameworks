from datetime import datetime
from fastapi import APIRouter, HTTPException, status, Query
from sqlmodel import select
from config.session_Dependencia import SessionDeDependencia
from config.segurity_Dependencia import Token_Dependencia
from config.permissions import require_admin_or_vendor, role_name
from models.detalle_venta import DetalleVenta, DetalleVentaCreate, DetalleVentaUpdate
from models.venta import Venta
from models.producto import Producto

router = APIRouter()


def validar_referencias(datos, session):
    venta = session.get(Venta, datos.id_venta)
    if not venta: raise HTTPException(status_code=404, detail=f"Venta con id {datos.id_venta} no encontrada")
    if not session.get(Producto, datos.id_producto): raise HTTPException(status_code=404, detail=f"Producto con id {datos.id_producto} no encontrado")
    return venta


def validar_acceso_venta(venta, token, session):
    if role_name(token, session) != "admin" and venta.id_usuario != token["id"]:
        raise HTTPException(status_code=403, detail="El vendedor solo puede trabajar con detalles de sus propias ventas")


def validar_editable(venta):
    if venta.estado.lower() != "editable":
        raise HTTPException(status_code=409, detail="La venta ya no está editable")

@router.get("/detalle-ventas", response_model=list[DetalleVenta], status_code=status.HTTP_200_OK)
def get_detalles(session: SessionDeDependencia, token: Token_Dependencia, offset: int = Query(0, ge=0), limit: int = Query(100, ge=1)):
    require_admin_or_vendor(token, session)
    if role_name(token, session) == "admin":
        return session.exec(select(DetalleVenta).offset(offset).limit(limit)).all()
    return session.exec(select(DetalleVenta).join(Venta).where(Venta.id_usuario == token["id"]).offset(offset).limit(limit)).all()

@router.get("/detalle-ventas/{id}", response_model=DetalleVenta, status_code=status.HTTP_200_OK)
def get_detalle(id: int, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    detalle = session.get(DetalleVenta, id)
    if not detalle: raise HTTPException(status_code=404, detail="Detalle de venta no encontrado")
    venta = session.get(Venta, detalle.id_venta)
    validar_acceso_venta(venta, token, session)
    return detalle

@router.post("/detalle-ventas", response_model=DetalleVenta, status_code=status.HTTP_201_CREATED)
def create_detalle(datos: DetalleVentaCreate, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    venta = validar_referencias(datos, session)
    validar_acceso_venta(venta, token, session)
    validar_editable(venta)
    detalle = DetalleVenta.model_validate(datos)
    session.add(detalle); session.commit(); session.refresh(detalle)
    return detalle

@router.delete("/detalle-ventas/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_detalle(id: int, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    detalle = session.get(DetalleVenta, id)
    if not detalle: raise HTTPException(status_code=404, detail="Detalle de venta no encontrado")
    venta = session.get(Venta, detalle.id_venta)
    validar_acceso_venta(venta, token, session)
    if role_name(token, session) != "admin": validar_editable(venta)
    session.delete(detalle); session.commit(); return None

@router.put("/detalle-ventas/{id}", response_model=DetalleVenta, status_code=status.HTTP_200_OK)
def update_detalle(id: int, datos: DetalleVentaUpdate, session: SessionDeDependencia, token: Token_Dependencia):
    require_admin_or_vendor(token, session)
    detalle = session.get(DetalleVenta, id)
    if not detalle: raise HTTPException(status_code=404, detail="Detalle de venta no encontrado")
    venta_actual = session.get(Venta, detalle.id_venta)
    validar_acceso_venta(venta_actual, token, session)
    if role_name(token, session) != "admin": validar_editable(venta_actual)
    nueva_venta = validar_referencias(datos, session)
    validar_acceso_venta(nueva_venta, token, session)
    if role_name(token, session) != "admin": validar_editable(nueva_venta)
    detalle.sqlmodel_update(datos.model_dump()); detalle.updated_at = datetime.utcnow()
    session.add(detalle); session.commit(); session.refresh(detalle)
    return detalle
